package com.BoxCricket.BoxCricket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoxCricketApplicationTests {

	@Test
	void contextLoads() {
	}

}
