package com.BoxCricket.BoxCricket.dto;

public enum BookingStatus {
    TEMPORARILY_BLOCKED,
    CONFIRMED,
    AVAILABLE
}
