package com.BoxCricket.BoxCricket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoxCricketApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoxCricketApplication.class, args);
	}

}
