package com.BoxCricket.BoxCricket.dto;

public enum Role {
    ADMIN,
    OWNER,
    USER
}
