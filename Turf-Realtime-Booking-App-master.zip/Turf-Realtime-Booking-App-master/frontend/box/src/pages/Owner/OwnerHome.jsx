import React from 'react'
import OwnerSidebar from './OwnerSidebar'

function OwnerHome() {
  return (
    <div className='bg-gray-800'>
    <OwnerSidebar />
    <div>OwnerHome</div>
    </div>

  )
}

export default OwnerHome